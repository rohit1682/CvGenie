
from django.db import models

class Personal(models.Model):
    name = models.CharField(max_length = 500, default='Nil')
    gender = models.CharField(max_length = 500, default='Nil')
    dob = models.CharField(max_length = 500, default='Nil')
    contactno = models.CharField(max_length = 500, default='Nil')
    email = models.CharField(max_length = 500, default='Nil')
    city = models.CharField(max_length = 500, default='Nil')
    country = models.CharField(max_length = 500, default='Nil')
    linkedin = models.CharField(max_length = 500, default='Nil')
    # pic=models.ImageField(upload_to='../static/uploads', null=True, blank=True)

class Education(models.Model):
    name = models.CharField(max_length = 500, default='Nil')
    startdate = models.CharField(max_length = 500, default='Nil')
    enddate = models.CharField(max_length = 500, default='Nil')
    percentage = models.CharField(max_length = 500, default='Nil')
    degree = models.CharField(max_length = 500, default='Nil')

class Skills(models.Model):
    techskills = models.CharField(max_length = 500, default='Nil')
    nontechskills = models.CharField(max_length = 500, default='Nil')

class ProfessionalExp(models.Model):
    name = models.CharField(max_length = 500, default='Nil')
    role = models.CharField(max_length = 500, default='Nil')
    tech = models.CharField(max_length = 500, default='Nil')
    start = models.CharField(max_length = 500, default='Nil')
    end = models.CharField(max_length = 500, default='Nil')

class VolunteerExp(models.Model):
    name = models.CharField(max_length = 500, default='Nil')
    role = models.CharField(max_length = 500, default='Nil')
    start = models.CharField(max_length = 500, default='Nil')
    end = models.CharField(max_length = 500, default='Nil')

class Project(models.Model):
    name = models.CharField(max_length = 500, default='Nil')
    tech = models.CharField(max_length = 500, default='Nil')
    details = models.CharField(max_length = 500, default='Nil')

class Achievements(models.Model):
    details = models.CharField(max_length = 500, default='Nil')
    link = models.CharField(max_length = 500, default='Nil')
    
