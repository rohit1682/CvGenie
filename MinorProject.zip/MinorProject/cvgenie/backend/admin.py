from django.contrib import admin

from backend.models import *

# Register your models here.

class PersonalAdmin(admin.ModelAdmin):
    list_display=('name','gender','dob','contactno','email','city','country','linkedin')
    # list_display=('name','gender','dob','contactno','email','city','country','linkedin','pic')


class EducationAdmin(admin.ModelAdmin):
    list_display=('name','startdate','enddate','percentage','degree')

class SkillsAdmin(admin.ModelAdmin):
    list_display=('techskills','nontechskills')

class ProfessionalExpAdmin(admin.ModelAdmin):
    list_display=('name','role','tech','start','end')

class VolunteerExpAdmin(admin.ModelAdmin):
    list_display=('name','role')

class ProjectAdmin(admin.ModelAdmin):
    list_display=('name','tech','details')

class AchievementsAdmin(admin.ModelAdmin):
    list_display=('details','link')

admin.site.register(Personal, PersonalAdmin)
admin.site.register(Education, EducationAdmin)
admin.site.register(Skills, SkillsAdmin)
admin.site.register(ProfessionalExp, ProfessionalExpAdmin)
admin.site.register(VolunteerExp, VolunteerExpAdmin)
admin.site.register(Project, ProjectAdmin)
admin.site.register(Achievements, AchievementsAdmin)
