$(document).ready(function() {
    // Add more professional experience
    // $('#addProfessionalExperience').click(function () {
    //     var clone = $('.professional-experience:first').clone();
    //     clone.find(':input').val('');
    //     clone.append('<button type="button" class="btn btn-danger btn-sm delete-section">Delete</button>');
    //     $('#professionalExperience').append(clone);
        
    // });

    $('#addProfessionalExperience').click(function () {
        var clone = $('.professional-experience:first').clone();
        var count = $('.professional-experience').length; // Get the count of existing sections
        clone.find(':input').each(function() {
            var oldName = $(this).attr('name');
            var newName = oldName.replace(/[0-9]+$/, count); // Replace the index in the name attribute
            $(this).attr('name', newName).val(''); // Set the new name value and clear input value
        });
        clone.append('<button type="button" class="btn btn-danger btn-sm delete-section">Delete</button>');
        $('#professionalExperience').append(clone);
    });

    // Add more volunteer experience
    $('#addVolunteerExperience').click(function () {
        var clone = $('.volunteer-experience:first').clone();
        clone.find(':input').val('');
        clone.append('<button type="button" class="btn btn-danger btn-sm delete-section">Delete</button>');
        $('#volunteerExperience').append(clone);
    });

    // Add more personal projects
    $('#addPersonalProject').click(function () {
        var clone = $('.personal-project:first').clone();
        clone.find(':input').val('');
        clone.append('<button type="button" class="btn btn-danger btn-sm delete-section">Delete</button>');
        $('#personalProjects').append(clone);
    });

    // Add more achievements
    $('#addAchievement').click(function () {
        var clone = $('.achievement:first').clone();
        clone.find(':input').val('');
        clone.append('<button type="button" class="btn btn-danger btn-sm delete-section">Delete</button>');
        $('#achievements').append(clone);
    });

    // Delete section
    $(document).on('click', '.delete-section', function () {
        $(this).closest('.professional-experience, .volunteer-experience, .personal-project, .achievement').remove();
    });
});

// // Function to handle form submission
// $('form').submit(function(event) {
//     // Prevent default form submission
//     event.preventDefault();

//     // Prepare data object to send via AJAX
//     var formData = {
        
//         'backend_name': $('#fullName').val(),
//         'backend_gender': $('#gender').val(),
//         'backend_dob': $('#dob').val(),
//         'backend_contactno': $('#contact').val(),
//         'backend_city' : $('#city').val(),
//         'backend_country' : $('#country').val(),
//         'backend_linkedin' : $('#linkedin').val(),

//         'education': [
//             {
//                 'name': $('#secondarySchoolName').val(),
//                 'startdate': $('#secondarySchoolStartDate').val(),
//                 'enddate': $('#secondarySchoolEndDate').val(),
//                 'percentage': $('#secondarySchoolPercentage').val()
//             },
//             {
//                 'name': $('#highSchoolName').val(),
//                 'startdate': $('#highSchoolStartDate').val(),
//                 'enddate': $('#highSchoolEndDate').val(),
//                 'percentage': $('#highSchoolPercentage').val()
//             },
//             {
//                 'name': $('#collegeName').val(),
//                 'startdate': $('#collegeStartDate').val(),
//                 'enddate': $('#collegeEndDate').val(),
//                 'percentage': $('#collegePercentage').val()
//             }
//         ],

//         'backend_techskills': $('#technicalSkills').val(),
//         'backend_nontechskills': $('#nonTechnicalSkills').val(),

//         // For Professional Experience
//         'backend_professional_experience': [],

//         // For Volunteer Experience
//         'backend_volunteer_experience': [],

//         // For Personal Projects
//         'backend_personal_projects': [],

//         // For Achievements
//         'backend_achievements': []
//     };

//     // Iterate over professional experiences and add to formData
//     $('.professional-experience').each(function(index) {
//         var exp = {};
//         exp['backend_name'] = $(this).find('.companyName').val();
//         exp['backend_role'] = $(this).find('.role').val();
//         exp['backend_tech'] = $(this).find('.technologiesUsed').val();
//         exp['backend_start'] = $(this).find('.startDate').val();
//         exp['backend_end'] = $(this).find('.endDate').val();
//         formData['backend_professional_experience'].push(exp);
//     });

//     // Iterate over volunteer experiences and add to formData
//     $('.volunteer-experience').each(function(index) {
//         var exp = {};
//         exp['backend_name'] = $(this).find('.orgName').val();
//         exp['backend_role'] = $(this).find('.roleContribution').val();
//         exp['backend_start'] = $(this).find('.volunteerStartDate').val();
//         exp['backend_end'] = $(this).find('.volunteerEndDate').val();
//         formData['backend_volunteer_experience'].push(exp);
//     });

//     // Iterate over personal projects and add to formData
//     $('.personal-project').each(function(index) {
//         var project = {};
//         project['backend_name'] = $(this).find('.projectName').val();
//         project['backend_tech'] = $(this).find('.projectTechnologies').val();
//         project['backend_details'] = $(this).find('.projectDetails').val();
//         formData['backend_personal_projects'].push(project);
//     });

//     // Iterate over achievements and add to formData
//     $('.achievement').each(function(index) {
//         var achievement = {};
//         achievement['backend_details'] = $(this).find('.achievementDetails').val();
//         achievement['backend_link'] = $(this).find('.certificateLink').val();
//         formData['backend_achievements'].push(achievement);
//     });

//     // Send AJAX request to Django view
//     $.ajax({
//         type: 'POST',
//         url: 'saveData/', // URL of your Django view
//         data: JSON.stringify(formData),
//         dataType: 'json',
//         contentType: 'application/json',
//         success: function(data) {
//             // Handle success response
//             console.log(data);
//             // Optionally, show a success message to the user
//         },
//         error: function(xhr, errmsg, err) {
//             // Handle error response
//             console.log(xhr.status + ": " + xhr.responseText); // Log error message
//             // Optionally, show an error message to the user
//         }
//     });
// });

// function getCookie(name) {
//     var cookieValue = null;
//     if (document.cookie && document.cookie !== '') {
//         var cookies = document.cookie.split(';');
//         for (var i = 0; i < cookies.length; i++) {
//             var cookie = jQuery.trim(cookies[i]);
//             // Check if cookie name matches the CSRF token cookie name
//             if (cookie.substring(0, name.length + 1) === (name + '=')) {
//                 cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
//                 break;
//             }
//         }
//     }
//     return cookieValue;
// }
