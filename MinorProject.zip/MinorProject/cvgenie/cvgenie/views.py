from django.http import HttpResponse
from django.shortcuts import render, redirect
import subprocess
import openai
import time

from backend.models import *

def homePage(request):
    return render(request, "index.html")

def loginPage(request):
    return render(request, "login.html")

def signupPage(request, pageDetails):
    if(pageDetails == "signup"):
        return render(request, "signup.html")

def genie(request):
    return render(request, "genie.html")

def form(request):
    return render(request, "form.html")

def resume(request):
    return render(request, "resume.html")

def get_completion(prompt, model="gpt-3.5-turbo"):

    openai.api_key  = "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"
    messages = [{"role": "user", "content": prompt}]
    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        temperature=0, 
    )
    return response.choices[0].message["content"]

def enhancing(file_path):
    text = []
    # file_path='../cvgenie/uploads/prof1.txt' 
    with open(file_path, 'r') as txtFile:
        for line in txtFile:
            text.append(line)
    print(text)
    result = []
    summary = ""  
    for i in range(len(text)):
        prompt = f"""
        Your task is to generate a Enhanced Summary  from the provided data for a resume of an individual .
        you will be given the professional experience.
        generate it in a first person speech     
        Extract relevant information from the following text.
        Text: ```{text[i]}```
        """
        try:
            response = get_completion(prompt) 
        except:
            response = get_completion(prompt)  
        print(response)
        summary = summary + ' ' + response + '\n\n'
        result.append(response)
        time.sleep(19) 
        with open(file_path, "w") as file:
            file.write(summary)

def enterData(request):
    
        if request.method=="POST":

            fullName=request.POST.get('fullName')
            gender=request.POST.get('gender')
            dob=request.POST.get('dob')
            email=request.POST.get('email')
            contact=request.POST.get('contact')
            city=request.POST.get('city')
            country=request.POST.get('country')
            linkedin=request.POST.get('linkedin')
            # pic=request.FILES['pic']

            Personal.objects.all().delete()

            q1=Personal(name=fullName,gender=gender,dob=dob,contactno=contact,email=email,city=city,country=country,linkedin=linkedin)

            q1.save()

            secondarySchoolName=request.POST.get('secondarySchoolName')
            secondarySchoolStartDate=request.POST.get('secondarySchoolStartDate')
            secondarySchoolEndDate=request.POST.get('secondarySchoolEndDate')
            secondarySchoolPercentage=request.POST.get('secondarySchoolPercentage')
            secondarySchoolDegree=request.POST.get('secondarySchoolQualification')

            highSchoolName=request.POST.get('highSchoolName')
            highSchoolStartDate=request.POST.get('highSchoolStartDate')
            highSchoolEndDate=request.POST.get('highSchoolEndDate')
            highSchoolPercentage=request.POST.get('highSchoolPercentage')
            highSchoolDegree=request.POST.get('highSchoolQualification')

            
            collegeName=request.POST.get('collegeName')
            collegeStartDate=request.POST.get('collegeStartDate')
            collegeEndDate=request.POST.get('collegeEndDate')
            collegePercentage=request.POST.get('collegePercentage')
            collegeDegree=request.POST.get('collegeQualification')

            Education.objects.all().delete()

            q2=Education(name=secondarySchoolName,startdate=secondarySchoolStartDate,enddate=secondarySchoolEndDate,percentage=secondarySchoolPercentage,degree=secondarySchoolDegree)

            q3=Education(name=highSchoolName,startdate=highSchoolStartDate,enddate=highSchoolEndDate,percentage=highSchoolPercentage,degree=highSchoolDegree)

            q4=Education(name=collegeName,startdate=collegeStartDate,enddate=collegeEndDate,percentage=collegePercentage,degree=collegeDegree)

            q2.save()
            q3.save()
            q4.save()

            Skills.objects.all().delete()

            technicalSkills=request.POST.get('technicalSkills')
            nonTechnicalSkills=request.POST.get('nonTechnicalSkills')

            q5=Skills(techskills=technicalSkills,nontechskills=nonTechnicalSkills)

            q5.save()

            ProfessionalExp.objects.all().delete()

            companyName1=request.POST.get('companyName1')
            role1=request.POST.get('role1')
            technologiesUsed1=request.POST.get('technologiesUsed1')
            startDate1=request.POST.get('startDate1')
            endDate1=request.POST.get('endDate1')

            companyName2=request.POST.get('companyName2')
            role2=request.POST.get('role2')
            technologiesUsed2=request.POST.get('technologiesUsed2')
            startDate2=request.POST.get('startDate2')
            endDate2=request.POST.get('endDate2')

            companyName3=request.POST.get('companyName3')
            role3=request.POST.get('role3')
            technologiesUsed3=request.POST.get('technologiesUsed3')
            startDate3=request.POST.get('startDate3')
            endDate3=request.POST.get('endDate3')

            if companyName1 != '':
                q6=ProfessionalExp(name=companyName1,role=role1,tech=technologiesUsed1,start=startDate1,end=endDate1)
                q6.save()

            if companyName2 != '':
                q7=ProfessionalExp(name=companyName2,role=role2,tech=technologiesUsed2,start=startDate2,end=endDate2)
                q7.save()

            if companyName3 != '':
                q8=ProfessionalExp(name=companyName3,role=role3,tech=technologiesUsed3,start=startDate3,end=endDate3)
                q8.save()

            if companyName1 != '':
                file_path = '../cvgenie/cvgenie/uploads/prof1.txt'
                with open(file_path, 'w') as f:
                    pass  
                f.close()
                with open(file_path, 'w') as f:  
                    f.write(f"The Company I worked in is: {companyName1}. The role i had in that company was: {role1}. The Technologies I used were: {technologiesUsed1}.")
                f.close()
                print('hello')
                enhancing(file_path)

            if companyName2 != '':
                file_path = '../cvgenie/cvgenie/uploads/prof2.txt'
                with open(file_path, 'w') as f:
                    pass  
                with open(file_path, 'a') as f: 
                    f.write(f"The Company I worked in is: {companyName2}. The role i had in that company was: {role2}. The Technologies I used were: {technologiesUsed2}.")
                f.close()
                

            if companyName3 != '':
                file_path = '../cvgenie/cvgenie/uploads/prof3.txt'
                with open(file_path, 'w') as file:
                    pass  
                with open(file_path, 'a') as f:  
                    f.write(f"The Company I worked in is: {companyName3}. The role i had in that company was: {role3}. The Technologies I used were: {technologiesUsed3}.")
                f.close()

            VolunteerExp.objects.all().delete()

            orgName1=request.POST.get('orgName1')
            roleContribution1=request.POST.get('roleContribution1')
            volunteerStartDate1=request.POST.get('volunteerStartDate1')
            volunteerEndDate1=request.POST.get('volunteerEndDate1')

            orgName2=request.POST.get('orgName2')
            roleContribution2=request.POST.get('roleContribution2')
            volunteerStartDate2=request.POST.get('volunteerStartDate2')
            volunteerEndDate2=request.POST.get('volunteerEndDate2')

            orgName3=request.POST.get('orgName3')
            roleContribution3=request.POST.get('roleContribution3')
            volunteerStartDate3=request.POST.get('volunteerStartDate3')
            volunteerEndDate3=request.POST.get('volunteerEndDate3')

            if orgName1 != '':
                q9=VolunteerExp(name=orgName1,role=roleContribution1,start=volunteerStartDate1,end=volunteerEndDate1)
                q9.save()

            if orgName2 != '':
                q10=VolunteerExp(name=orgName2,role=roleContribution2,start=volunteerStartDate2,end=volunteerEndDate2)
                q10.save()

            if orgName3 != '':
                q11=VolunteerExp(name=orgName3,role=roleContribution3,start=volunteerStartDate3,end=volunteerEndDate3)
                q11.save()

            if orgName1 != '':
                file_path = '../cvgenie/cvgenie/uploads/volun1.txt'
                with open(file_path, 'w') as f:
                    pass  

                with open(file_path, 'a') as f:  
                    f.write(f"The Organization I worked in is: {orgName1}. The role i had in that organization was: {roleContribution1}.")
                f.close()
                

            if orgName2 != '':
                file_path = '../cvgenie/cvgenie/uploads/volun2.txt'
                with open(file_path, 'w') as f:
                    pass  

                with open(file_path, 'a') as f:  
                    f.write(f"The Organization I worked in is: {orgName2}. The role i had in that organization was: {roleContribution2}.")
                f.close()

            if orgName3 != '':
                file_path = '../cvgenie/cvgenie/uploads/volun3.txt'
                with open(file_path, 'w') as f:
                    pass  

                with open(file_path, 'a') as f:  
                    f.write(f"The Organization I worked in is: {orgName3}. The role i had in that organization was: {roleContribution3}.")
                f.close()

            Project.objects.all().delete()

            projectName1=request.POST.get('projectName1')
            projectTechnologies1=request.POST.get('projectTechnologies1')
            projectDetails1=request.POST.get('projectDetails1')

            projectName2=request.POST.get('projectName2')
            projectTechnologies2=request.POST.get('projectTechnologies2')
            projectDetails2=request.POST.get('projectDetails2')

            projectName3=request.POST.get('projectName3')
            projectTechnologies3=request.POST.get('projectTechnologies3')
            projectDetails3=request.POST.get('projectDetails3')

            if projectName1 != '':
                q12=Project(name=projectName1,tech=projectTechnologies1,details=projectDetails1)
                q12.save()

            if projectName2 != '':
                q13=Project(name=projectName2,tech=projectTechnologies2,details=projectDetails2)
                q13.save()

            if projectName3 != '':
                q14=Project(name=projectName3,tech=projectTechnologies3,details=projectDetails3)
                q14.save()

            Achievements.objects.all().delete()

            achievementDetails1=request.POST.get('achievementDetails1')
            certificateLink1=request.POST.get('certificateLink1')

            achievementDetails2=request.POST.get('achievementDetails2')
            certificateLink2=request.POST.get('certificateLink2')

            achievementDetails3=request.POST.get('achievementDetails3')
            certificateLink3=request.POST.get('certificateLink3')

            if achievementDetails1 != '':
                q14=Achievements(details=achievementDetails1,link=certificateLink1)
                q14.save()

            if achievementDetails2 != '':
                q15=Achievements(details=achievementDetails2,link=certificateLink2)
                q15.save()

            if achievementDetails3 != '':
                q16=Achievements(details=achievementDetails3,link=certificateLink3)
                q16.save()

            data = {
                'fullName': fullName,
                'gender': gender,
                'dob': dob,
                'email': email,
                'contact': contact,
                'city': city,
                'country': country,
                'linkedin': linkedin,

                'secondarySchoolName': secondarySchoolName,
                'secondarySchoolStartDate': secondarySchoolStartDate,
                'secondarySchoolEndDate': secondarySchoolEndDate,
                'secondarySchoolPercentage': secondarySchoolPercentage,
                'highSchoolName': highSchoolName,
                'highSchoolStartDate': highSchoolStartDate,
                'highSchoolEndDate': highSchoolEndDate,
                'highSchoolPercentage': highSchoolPercentage,
                'collegeName': collegeName,
                'collegeStartDate': collegeStartDate,
                'collegeEndDate': collegeEndDate,
                'collegePercentage': collegePercentage,

                'technicalSkills': technicalSkills,
                'nonTechnicalSkills': nonTechnicalSkills,

                'companyName1': companyName1,
                'role1': role1,
                'technologiesUsed1': technologiesUsed1,
                'startDate1': startDate1,
                'endDate1': endDate1,
                'companyName2': companyName2,
                'role2': role2,
                'technologiesUsed2': technologiesUsed2,
                'startDate2': startDate2,
                'endDate2': endDate2,
                'companyName3': companyName3,
                'role3': role3,
                'technologiesUsed3': technologiesUsed3,
                'startDate3': startDate3,
                'endDate3': endDate3,

                'orgName1': orgName1,
                'roleContribution1': roleContribution1,
                'volunteerStartDate1': volunteerStartDate1,
                'volunteerEndDate1': volunteerEndDate1,
                'orgName2': orgName2,
                'roleContribution2': roleContribution2,
                'volunteerStartDate2': volunteerStartDate2,
                'volunteerEndDate2': volunteerEndDate2,
                'orgName3': orgName3,
                'roleContribution3': roleContribution3,
                'volunteerStartDate3': volunteerStartDate3,
                'volunteerEndDate3': volunteerEndDate3,
                
                'projectName1': projectName1,
                'projectTechnologies1': projectTechnologies1,
                'projectDetails1': projectDetails1,
                'projectName2': projectName2,
                'projectTechnologies2': projectTechnologies2,
                'projectDetails2': projectDetails2,
                'projectName3': projectName3,
                'projectTechnologies3': projectTechnologies3,
                'projectDetails3': projectDetails3,

                'achievementDetails1': achievementDetails1,
                'certificateLink1': certificateLink1,
                'achievementDetails2': achievementDetails2,
                'certificateLink2': certificateLink2,
                'achievementDetails3': achievementDetails3,
                'certificateLink3': certificateLink3,
            }

        return render(request,'resume.html', data)


            # print(fullName)
            # print(gender)
            # print(dob)
            # print(email)
            # print(contact)
            # print(city)
            # print(country)
            # print(linkedin)

            # print(secondarySchoolName)
            # print(secondarySchoolStartDate)
            # print(secondarySchoolEndDate)
            # print(secondarySchoolPercentage)

            # print(highSchoolName)
            # print(highSchoolStartDate)
            # print(highSchoolEndDate)
            # print(highSchoolPercentage)

            # print(collegeName)
            # print(collegeStartDate)
            # print(collegeEndDate)
            # print(collegePercentage)

            # print(technicalSkills)
            # print(nonTechnicalSkills)

            # print(companyName1)
            # print(role1)
            # print(technologiesUsed1)
            # print(startDate1)
            # print(endDate1)

            # print(companyName2)
            # print(role2)
            # print(technologiesUsed2)
            # print(startDate2)
            # print(endDate2)

            # print(companyName3)
            # print(role3)
            # print(technologiesUsed3)
            # print(startDate3)
            # print(endDate3)

            # print(orgName1)
            # print(roleContribution1)
            # print(volunteerStartDate1)
            # print(volunteerEndDate1)

            # print(orgName2)
            # print(roleContribution2)
            # print(volunteerStartDate2)
            # print(volunteerEndDate2)

            # print(orgName3)
            # print(roleContribution3)
            # print(volunteerStartDate3)
            # print(volunteerEndDate3)

            # print(projectName1)
            # print(projectTechnologies1)
            # print(projectDetails1)

            # print(projectName2)
            # print(projectTechnologies2)
            # print(projectDetails2)

            # print(projectName3)
            # print(projectTechnologies3)
            # print(projectDetails3)

            # print(achievementDetails1)
            # print(certificateLink1)

            # print(achievementDetails2)
            # print(certificateLink2)

            # print(achievementDetails3)
            # print(certificateLink3)

            # professional_experiences = []  
        
            # num_sections = len(request.POST.getlist('companyName_1'))
            # print(num_sections)

            # for i in range(num_sections):
            #     company_name = request.POST.get(f'companyName_{i}')
            #     role = request.POST.get(f'role_{i}')
            #     technologies_used = request.POST.get(f'technologiesUsed_{i}')
            #     start_date = request.POST.get(f'startDate_{i}')
            #     end_date = request.POST.get(f'endDate_{i}')

            #     experience = {
            #         'company_name': company_name,
            #         'role': role,
            #         'technologies_used': technologies_used,
            #         'start_date': start_date,
            #         'end_date': end_date
            #     }

            #     professional_experiences.append(experience)

            # print("Professional Experiences:", professional_experiences)

            # ,fullName,
            # gender,
            # dob,
            # email,
            # contact,
            # city,
            # country,
            # linkedin,
            # secondarySchoolName,
            # secondarySchoolStartDate,
            # secondarySchoolEndDate,
            # secondarySchoolPercentage,
            # highSchoolName,
            # highSchoolStartDate,
            # highSchoolEndDate,
            # highSchoolPercentage,
            # collegeName,
            # collegeStartDate,
            # collegeEndDate,
            # collegePercentage,
            # technicalSkills,
            # nonTechnicalSkills,
            # companyName1,
            # role1,
            # technologiesUsed1,
            # startDate1,
            # endDate1,
            # companyName2,
            # role2,
            # technologiesUsed2,
            # startDate2,
            # endDate2,
            # companyName3,
            # role3,
            # technologiesUsed3,
            # startDate3,
            # endDate3,
            # orgName1,
            # roleContribution1,
            # volunteerStartDate1,
            # volunteerEndDate1,
            # orgName2,
            # roleContribution2,
            # volunteerStartDate2,
            # volunteerEndDate2,
            # orgName3,
            # roleContribution3,
            # volunteerStartDate3,
            # volunteerEndDate3,
            # projectName1,
            # projectTechnologies1,
            # projectDetails1,
            # projectName2,
            # projectTechnologies2,
            # projectDetails2,
            # projectName3,
            # projectTechnologies3,
            # projectDetails3,
            # achievementDetails1,
            # certificateLink1,
            # achievementDetails2,
            # certificateLink2,
            # achievementDetails3,
            # certificateLink3

            