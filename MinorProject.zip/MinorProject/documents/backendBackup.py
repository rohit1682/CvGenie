from django.db import models

# from . import backend

# Create your models here.


class Personal(models.Model):
    backend_name = models.TextField()
    backend_gender = models.TextField()
    backend_dob = models.TextField()
    backend_pname = models.TextField()
    backend_contactno = models.TextField()
    backend_email = models.TextField()
    backend_address = models.TextField()
    backend_linkedin = models.TextField()
    backend_website = models.TextField()

class Education(models.Model):
    backend_name = models.TextField()
    backend_startdate = models.TextField()
    backend_enddate = models.TextField()
    backend_percentage = models.TextField()

class TechSkills(models.Model):
    backend_skills = models.TextField()

class NonTechSkills(models.Model):
    backend_skills = models.TextField()

class ProfessionalExp(models.Model):
    backend_name = models.TextField()
    backend_role = models.TextField()
    backend_tech = models.TextField()
    backend_other = models.TextField()
    backend_start = models.TextField()
    backend_end = models.TextField()

class VolunteerExp(models.Model):
    backend_name = models.TextField()
    backend_role = models.TextField()
    backend_contribution = models.TextField()

class Project(models.Model):
    backend_name = models.TextField()
    backend_tech = models.TextField()
    backend_details = models.TextField()

class Achievements(models.Model):
    backend_name = models.TextField()
    backend_role = models.TextField()
    
